
<?php /**PATH C:\xampp\htdocs\photofery\resources\views/frontend/partials/header.blade.php ENDPATH**/ ?>