<?php $__env->startSection('content'); ?>
<?php echo $__env->make('backend.partials.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     
 <div class="form-body">       
  <h3 class="text-center">Image Slider</h3>
        
  <form action="<?php echo e(route('imageslidercreateprocess')); ?>" method="post" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <div class="form-group">
      
          <input type="file" name="image" class="form-control" id="name" placeholder="Enter name">
        </div>
         <div class="form-group">
        <button type="submit" class="btn btn-primary form-control">Upload Image</button>
      </div>
    </form>
  </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\photofery\resources\views/backend/imageslider/imageslidercreate.blade.php ENDPATH**/ ?>