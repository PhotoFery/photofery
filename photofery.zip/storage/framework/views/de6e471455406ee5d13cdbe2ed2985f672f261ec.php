<!DOCTYPE HTML>
<html lang="en">

<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

<title>Photography</title>
<meta name="keywords" content=""  />
<meta name="description" content=""/>
<link rel="icon" type="image/ico" href="">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;500;600;700;800&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700;800&display=swap" rel="stylesheet">
<link href="<?php echo e(asset('/public/css/app.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/public/css/all.css')); ?>" rel="stylesheet">
</head>
<body>
<div class="login">
	<div class="container">
    <div class="login-body">
    <div class="row">
      <div class="col-lg-12">
          <?php echo $__env->make('admin.partials.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <h3 class="text-center">Login</h3>
        <form action="<?php echo e(route('login')); ?>" method="post">
      <?php echo csrf_field(); ?>
      
        <div class="form-group">
          <input type="email" name="email" class="form-control" id="email" placeholder="Enter email" value="<?php echo e(old('email')); ?>">
        </div>
        <div class="form-group">
          <input type="password" name="password" class="form-control" id="password" placeholder="Password">
        </div>
         <div class="form-group">
        <button type="submit" class="btn btn-primary form-control btn-login">Login</button>
      </div>
      
    </form>
      </div>
    </div>
    </div>
		
	</div>
</div>
<script type="text/javascript">
    // Notice how this gets configured before we load Font Awesome
    window.FontAwesomeConfig = { autoReplaceSvg: false }
    </script>
<script src="<?php echo e(asset('/public/js/all.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\photofery\resources\views/admin/login.blade.php ENDPATH**/ ?>