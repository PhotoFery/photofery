<?php $__env->startSection('content'); ?>
<?php echo $__env->make('backend.partials.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="form-body">

        <h3 class="text-center">Create New Admin</h3>
        <form action="<?php echo e(route('createadmin')); ?>" method="post">
      <?php echo csrf_field(); ?>
      <div class="form-group">
      
          <input type="name" name="name" class="form-control" id="name" placeholder="Enter name" value="<?php echo e(old('name')); ?>">
        </div>
        <div class="form-group">
      
          <input type="email" name="email" class="form-control" id="email" placeholder="Enter email" value="<?php echo e(old('email')); ?>">
        </div>
        <div class="form-group">
     
          <input type="password" name="password" class="form-control" id="password" placeholder="Password">
        </div>
        <div class="form-group">
       
          <input type="password" name="c_password" class="form-control" id="password" placeholder="Confirm Password">
        </div>
         <div class="form-group">
        <button type="submit" class="btn btn-primary form-control">Create New Admin</button>
      </div>
    </form>
  </div>  
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\photofery\resources\views/backend/admin/createadmin.blade.php ENDPATH**/ ?>