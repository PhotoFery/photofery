<?php $__env->startSection('content'); ?>
<?php echo $__env->make('backend.partials.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="form-body">
        <h3 class="text-center">Admin List</h3>
        
    <table class="table table-responsive">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Handle</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $createadminlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $createadminlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($createadminlist->id); ?></th>
      <td><?php echo e($createadminlist->name); ?></td>
      <td><?php echo e($createadminlist->email); ?></td>
      <td>
        <?php if($createadminlist->id != 5): ?>
        <div class="d-flex justify-content-start">
        <a class="edit-a-edit mr-4" href="<?php echo e(route('createadminupdate',$createadminlist->id)); ?>">Edit</a> 
      
<form action="<?php echo e(route('createadmindelete',$createadminlist->id)); ?>" method="post">
  <?php echo csrf_field(); ?>
  <button class="edit-a-delete" type="submit">Delete</button>
</form>
</div>
 <?php endif; ?> 
  </td>      
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\photofery\resources\views/backend/admin/createadminlist.blade.php ENDPATH**/ ?>