<?php $__env->startSection('content'); ?>
<?php echo $__env->make('backend.partials.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="form-body">
        <h3 class="text-center">Messages List</h3>
        <?php if(count($messagelists) > 0): ?>  
    <table class="table  table-responsive">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Message</th>
      <th scope="col">Handle</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $messagelists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($message->id); ?></th>
      <td><?php echo e($message->name); ?></td>
      <td><?php echo e($message->email); ?></td>
      <td><?php echo e($message->message); ?></td>
      <td>
       <form action="<?php echo e(route('messagedelete',$message->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <button class="edit-a-delete" type="submit">Delete</button>
      </form>
      </td>      
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php else: ?> 
    <p>Data not found</p>
<?php endif; ?>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\photofery\resources\views/backend/message/messagelist.blade.php ENDPATH**/ ?>