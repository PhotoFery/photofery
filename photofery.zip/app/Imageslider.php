<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Imageslider extends Model
{
     protected $fillable = [
        'image'
    ];
}
