
<footer class="footer text-center padd-35">
    <div class="container">
          <ul class="footer-nav-link">
            <li><a href="{{ route('about') }}">ABOUT PHOTOFERY</a></li>
            <li><a href="{{ route('termscondition') }}">TERMS OF SERVICE</a></li>
            <li><a href="{{ route('contact') }}">Contact Us</a></li>
          </ul>
        <ul class="footer-social">
            <li><a href="https://www.facebook.com/photoferry/" target="_blank"><i class="fab fa-facebook-f" aria-hidden="true"></i></a></li>
            <li><a href="https://twitter.com/photofery"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
            <li><a href="https://www.instagram.com/photoferyteam"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>
        </ul>
        <div class="copyright">
          2020 Copyright <strong>Photofery</strong>. ALL RIGHTS RESERVED
        </div>
    </div>
  </footer>




